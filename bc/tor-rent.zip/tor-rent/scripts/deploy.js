const { ethers } = require("hardhat");

async function main() {
    // Get the contract factory
    const RentalContract = await ethers.getContractFactory("RentalContract");
    
    console.log("Deploying RentalContract...");
    const rentalAgreement = await RentalContract.deploy();
    
    // In newer versions of ethers, we use waitForDeployment() instead of deployed()
    await rentalAgreement.waitForDeployment();
    
    // In newer versions, we use getAddress() instead of .address
    const address = await rentalAgreement.getAddress();
    console.log("RentalContract deployed at:", address);
}

main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
});